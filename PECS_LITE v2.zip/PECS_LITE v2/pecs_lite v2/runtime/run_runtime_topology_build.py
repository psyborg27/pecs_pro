from pecs_lite_runtime_v2 import PECSLiteRuntimeV2


WORKSPACE_ROOT = "."
OUTPUT_FILE = "pecs_runtime_topology.json"


runtime = PECSLiteRuntimeV2(WORKSPACE_ROOT)

runtime.build_runtime_topology()
runtime.export_runtime_topology(OUTPUT_FILE)

print("PECS-LITE v2 runtime topology export complete.")