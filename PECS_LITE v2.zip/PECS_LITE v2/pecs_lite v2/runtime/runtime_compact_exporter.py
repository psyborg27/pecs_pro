import json
from pathlib import Path


class RuntimeCompactExporter:
    """
    Produces compressed runtime projection exports for PECS-LITE.

    Goal:
    - low token footprint
    - runtime workspace targets
    - execution locality hints
    - small-model friendly structure
    - explicit infrastructure disclaimer
    """

    DISCLAIMER = (
        "THIS FILE IS GENERATED RUNTIME LOCALITY PROJECTION INFRASTRUCTURE. "
        "DO NOT EDIT. DO NOT PATCH. "
        "ENGINEERING TRUTH EXISTS ONLY IN WORKSPACE RUNTIME MODULES."
    )

    def _flatten_targets(self, topology_index):
        runtime_targets = set()
        for targets in topology_index.values():
            if isinstance(targets, list):
                runtime_targets.update(str(item).strip() for item in targets if item)
        return sorted(runtime_targets)

    def _guess_cluster(self, runtime_targets):
        cluster_counts = {}
        for path in runtime_targets:
            parts = [p for p in path.replace('\\', '/').split('/') if p]
            if not parts:
                continue
            cluster = '/'.join(parts[:2]) if len(parts) >= 2 else parts[0]
            cluster_counts[cluster] = cluster_counts.get(cluster, 0) + 1
        if not cluster_counts:
            return "general_runtime"
        return max(cluster_counts, key=lambda key: (cluster_counts[key], key))

    def _guess_zone(self, topology_index):
        if topology_index.get('subprocess_files'):
            return 'subprocess_pipeline'
        if topology_index.get('dialogs'):
            return 'ui_dialog_pipeline'
        if topology_index.get('dispatch_files') or topology_index.get('signal_slot_files'):
            return 'event_dispatch_pipeline'
        if topology_index.get('ui_action_files'):
            return 'ui_action_pipeline'
        return 'general_runtime'

    def _guess_owner(self, topology_index):
        for key in ('dispatch_files', 'signal_slot_files', 'ui_action_files', 'subprocess_files', 'dialogs'):
            files = topology_index.get(key)
            if isinstance(files, list) and files:
                return str(files[0]).strip()
        return ''

    def export(self, output_path, topology_index):
        output_path = Path(output_path)
        runtime_targets = self._flatten_targets(topology_index)

        payload = {
            'schema': 'pecs_lite.runtime_projection.v1',
            'disclaimer': self.DISCLAIMER,
            'runtime_targets': runtime_targets,
            'likely_execution_cluster': self._guess_cluster(runtime_targets),
            'runtime_zone': self._guess_zone(topology_index),
            'wrapper_warning': len(runtime_targets) == 0,
            'possible_mutation_owner': self._guess_owner(topology_index),
            'continuity_supporting_artifacts': [
                'runtime locality projection only',
                'PECS-LITE does not own runtime truth',
            ],
        }

        output_path.write_text(
            json.dumps(payload, indent=2),
            encoding='utf-8'
        )