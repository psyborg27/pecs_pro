from pathlib import Path

from pecs_lite.runtime.pecs_lite_runtime_v2 import (
    PECSLiteRuntimeV2,
)

OUTPUT_FILE = "pecs_runtime_topology.json"

if __name__ == "__main__":
    workspace_root = Path.cwd()

    runtime = PECSLiteRuntimeV2(
        str(workspace_root)
    )

    topology = runtime.build_runtime_topology()

    runtime.export_runtime_topology(
        OUTPUT_FILE
    )

    print(
        "PECS-LITE v2 runtime topology export complete."
    )

    print(topology)