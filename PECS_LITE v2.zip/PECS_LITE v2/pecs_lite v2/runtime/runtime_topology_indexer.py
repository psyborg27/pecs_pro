class RuntimeTopologyIndexer:
    """
    Compressed runtime topology index.

    Designed for:
    - small-context inference
    - compressed continuity export
    - lightweight retrieval
    """

    def build(self, topology):
        return {
            "ui_action_files": topology.get("ui_actions", []),
            "signal_slot_files": topology.get("signal_slots", []),
            "dialog_files": topology.get("dialogs", []),
            "subprocess_files": topology.get("subprocesses", []),
            "dispatch_files": topology.get("dispatch", [])
        }