class DispatchChainMapper:
    """
    Lightweight dispatch-chain reconstruction.

    Tracks:
    - dialog launches
    - OCR dispatch
    - viewer dispatch
    - feature launch routing
    """

    def create_dispatch_record(
        self,
        source_file,
        owner,
        target,
        dispatch_type
    ):
        return {
            "source_file": source_file,
            "owner": owner,
            "target": target,
            "dispatch_type": dispatch_type
        }