class RuntimeTraceRegistry:
    """
    Lightweight runtime trace registry.

    PECS-LITE v2 stores:
    - compressed runtime ownership
    - dispatch continuity
    - QAction locality
    - signal-slot locality

    WITHOUT storing:
    - full semantic trees
    - recursive dependency graphs
    """

    def __init__(self):
        self.records = {}

    def register(self, key, value):
        self.records[key] = value

    def get(self, key, default=None):
        return self.records.get(key, default)

    def export(self):
        return self.records