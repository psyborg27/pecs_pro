from pathlib import Path
import re


class RuntimeInteractionMapper:
    """
    Lightweight runtime topology extractor.

    PECS-LITE intentionally avoids:
    - AST-heavy parsing
    - recursive semantic analysis
    - dependency graph explosion

    Instead it performs:
    - deterministic pattern extraction
    - compressed runtime locality projection
    """

    EXCLUDED_DIRS = {
        ".git",
        ".venv",
        "venv",
        "env",
        "node_modules",
        "__pycache__",
        "build",
        "dist",
        ".pecs",
        ".eggs",
    }

    QAction_PATTERN = re.compile(r"QAction\(")
    CONNECT_PATTERN = re.compile(r"\.connect\(")
    SUBPROCESS_PATTERN = re.compile(r"subprocess\.")
    DIALOG_PATTERN = re.compile(r"\.exec\(")

    def __init__(self, workspace_root):
        self.workspace_root = Path(workspace_root)

    def scan_workspace(self):
        topology = {
            "ui_actions": [],
            "signal_slots": [],
            "dialogs": [],
            "subprocesses": [],
            "dispatch": []
        }

        for py_file in self.workspace_root.rglob("*.py"):
            if self._is_excluded(py_file):
                continue
            self._scan_file(py_file, topology)

        return topology

    def _is_excluded(self, path: Path) -> bool:
        return any(part in self.EXCLUDED_DIRS for part in path.parts)

    def _scan_file(self, py_file, topology):
        try:
            text = py_file.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return

        try:
            file_path = str(py_file.relative_to(self.workspace_root))
        except ValueError:
            file_path = str(py_file)

        if self.QAction_PATTERN.search(text):
            topology["ui_actions"].append(file_path)

        if self.CONNECT_PATTERN.search(text):
            topology["signal_slots"].append(file_path)

        if self.DIALOG_PATTERN.search(text):
            topology["dialogs"].append(file_path)

        if self.SUBPROCESS_PATTERN.search(text):
            topology["subprocesses"].append(file_path)

        if (
            "triggered.connect" in text
            or ".clicked.connect" in text
            or ".exec(" in text
        ):
            topology["dispatch"].append(file_path)