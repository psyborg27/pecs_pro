import re


class SignalSlotReconstructor:
    """
    Compressed Qt signal-slot reconstruction.

    Goal:
    - runtime continuity
    - lightweight extraction
    - deterministic indexing

    NOT:
    - full AST inference
    """

    CONNECT_REGEX = re.compile(
        r"(\w+)\.(clicked|triggered|connect)\.connect\((.*?)\)"
    )

    def reconstruct(self, source_text):
        chains = []

        for match in self.CONNECT_REGEX.finditer(source_text):
            chains.append({
                "source": match.group(1),
                "signal": match.group(2),
                "target": match.group(3)
            })

        return chains