import re


class UIActionRegistryMapper:
    """
    QAction ownership extractor.

    Used to reconstruct:
    - menu ownership
    - toolbar ownership
    - dispatch locality
    """

    ACTION_REGEX = re.compile(
        r"QAction\((.*?)\)"
    )

    ADD_ACTION_REGEX = re.compile(
        r"addAction\((.*?)\)"
    )

    def extract(self, source_text):
        actions = []

        for match in self.ACTION_REGEX.finditer(source_text):
            actions.append({
                "type": "QAction",
                "value": match.group(1)
            })

        for match in self.ADD_ACTION_REGEX.finditer(source_text):
            actions.append({
                "type": "addAction",
                "value": match.group(1)
            })

        return actions