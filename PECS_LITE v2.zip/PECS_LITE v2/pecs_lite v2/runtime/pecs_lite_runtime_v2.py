from runtime_interaction_mapper import RuntimeInteractionMapper
from runtime_topology_indexer import RuntimeTopologyIndexer
from runtime_trace_registry import RuntimeTraceRegistry
from runtime_compact_exporter import RuntimeCompactExporter


class PECSLiteRuntimeV2:
    """
    PECS-LITE v2 Runtime

    Continuity-first.
    Topology-aware.
    Small-model optimized.
    """

    def __init__(self, workspace_root):
        self.workspace_root = workspace_root

        self.mapper = RuntimeInteractionMapper(workspace_root)
        self.indexer = RuntimeTopologyIndexer()
        self.registry = RuntimeTraceRegistry()
        self.exporter = RuntimeCompactExporter()

    def build_runtime_topology(self):
        topology = self.mapper.scan_workspace()

        index = self.indexer.build(topology)

        self.registry.register("runtime_topology", index)

        return index

    def export_runtime_topology(self, output_path):
        topology = self.registry.get("runtime_topology", {})

        self.exporter.export(output_path, topology)