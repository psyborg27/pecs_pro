# PECS-LITE v2

Persistent Engineering Continuity System — Lite Projection Layer

PECS-LITE v2 is an LLM-facing locality projection layer designed to:

- identify runtime workspace target files
- project likely execution clusters
- infer runtime zones
- produce compact, low-token outputs
- optimize for small local LLMs

PECS-LITE v2 does NOT:

- reconstruct full topology as authoritative source
- duplicate continuity authority
- own runtime engineering truth
- expose `.pecs` artifacts as edit targets

PECS-LITE v2 focuses on:

- runtime target projection
- locality cluster projection
- execution neighborhood projection
- runtime-zone projection
- wrapper warnings for broad candidate sets
- compact retrieval shaping
- small-model optimized outputs

PECS-LITE v2 intentionally avoids:

- semantic orchestration
- recursive dependency expansion
- AST-heavy reconstruction
- autonomous reconciliation
- large runtime agents

Architecture Layers:

- continuity/
    compressed continuity models and registries

- runtime/
    projection-oriented runtime topology extraction

- integrations/
    Continue/Copilot projection export integration

- exports/
    generated runtime locality projection outputs

PECS-LITE v2 treats:

RUNTIME WORKSPACE TARGETS

as the output of projection, while keeping runtime workspace modules as authoritative engineering truth.