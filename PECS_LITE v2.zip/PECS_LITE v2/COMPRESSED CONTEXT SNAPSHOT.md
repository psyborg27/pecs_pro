# PECS DEVELOPMENT STATE — COMPRESSED CONTEXT SNAPSHOT

## PECS FULL FORM

Persistent Engineering Continuity System

---

# PRIMARY ARCHITECTURAL DISCOVERY

The original PECS architecture was insufficient because it modeled:

static continuity

instead of:

runtime interaction topology

The user’s Qt application proved that actual continuity exists primarily in:

- QAction registration
- signal-slot chains
- runtime dispatch
- dialog launch chains
- subprocess orchestration
- overlay propagation
- viewer ownership
- callback topology
- execution chains
- runtime-composed UI ownership

This became clear after continuity reconstruction passes identified:
- correct entrypoints
- correct top-level ownership

BUT failed to deeply reconstruct:
- OCR UI chains
- bulk mapper ownership
- overlay dispatch
- EasyOCR subprocess routing
- PDF viewer ownership
- annotation manager wiring
- export/save topology
- help menu topology
- modular runtime injection paths

---

# FINAL PECS PRINCIPLE

PECS is:

deterministic continuity infrastructure

NOT:

autonomous engineering intelligence

PECS must remain:
- deterministic
- topology-indexed
- continuity-oriented
- confidence-based
- lightweight relative to project scale

PECS must NOT become:
- recursive AI orchestration
- autonomous agent systems
- self-modifying architecture
- AGI-style semantic engineering

---

# CONTINUITY AUTHORITY HIERARCHY

## LEVEL 1 — LIVE WIRED REALITY (highest authority)

Use:
- runtime wiring
- actual imports
- actual dispatch paths
- signal-slot chains
- method calls
- runtime ownership
- active execution chains
- subprocess launch chains

as primary truth.

---

## LEVEL 2 — CURRENT WORKSPACE STATE

Use:
- existing files
- current modules
- current ownership
- active locality

as secondary authority.

---

## LEVEL 3 — CURRENT SESSION CONTEXT

Use:
- current debugging focus
- current engineering goals
- current runtime observations

as temporary active context.

---

## LEVEL 4 — AI CHAT DUMP (lowest authority)

Treat ONLY as:
- historical continuity memory
- regression history
- architectural archaeology
- continuity hints

NOT:
- authoritative structural truth

The AI dump must NEVER override live runtime topology.

---

# MAJOR ARCHITECTURAL REALIZATION

Complex GUI continuity is:

execution-topological

NOT:

file-hierarchical

This became the defining PECS v2 principle.

---

# PECS v1 LIMITATIONS DISCOVERED

PECS v1 mostly modeled:
- imports
- files
- locality
- duplicate files
- static continuity

This proved insufficient for:
- Qt applications
- runtime-composed UI systems
- signal-slot architectures
- delayed runtime injection
- overlay systems
- subprocess orchestration
- execution continuity

Thus prompting became necessary.

This revealed:

the continuity engine itself needed topology reconstruction

NOT merely:
- better prompts
- better summaries
- better indexing

---

# USER APPLICATION CONTINUITY DISCOVERIES

The continuity reconstruction correctly identified:

## Canonical runtime spine

main_app.py
→ MainAppLogic
→ MainAppUI
→ QAction registration
→ runtime dispatch
→ dialog launch
→ backend orchestration

---

## Runtime ownership

Qt/main_app_UI_rewrite.py owns:
- menu registration
- toolbar wiring
- OCR launch chains
- Auto-TOC launch chains
- portfolio launch
- viewer integration
- notes integration
- export/save flows

---

## Regression-prone zones

- notes ↔ viewer integration
- Auto-TOC OCR branch
- Cmd+F propagation
- duplicate module drift
- startup Qt initialization

---

## Duplicate evolution clusters

Detected for:
- main_app
- UI rewrite
- auto_toc_camlt
- notes_module_v2
- auto_toc_dialog_rewrite

---

# CRITICAL NEW REQUIREMENT

PECS must eventually track:
- every QAction
- every dispatch
- every callback
- every method chain
- every subprocess call
- overlay propagation
- OCR execution chains
- viewer state propagation
- execution ownership
- dispatch locality

to infer:
- true runtime canonicals
- true continuity ownership
- actual locality
- actual execution topology

---

# PECS-LITE v2 STATUS

PECS-LITE v2 architecture was started.

Design goal:

high continuity density
low token overhead

optimized for:
- 8k models
- 16k models
- 32k models
- local inference

PECS-LITE v2 intentionally avoids:
- AST explosion
- recursive dependency graphs
- semantic orchestration
- autonomous reconciliation
- heavy runtime agents

---

# PECS-LITE v2 CORE STRUCTURE

pecs_lite/

    continuity/
        pecs_lite_object_model.py
        pecs_lite_registry.py

    integrations/
        pecs_lite_continue_adapter.py

    runtime/
        pecs_lite_runtime_v2.py
        run_lite.py
        run_runtime_topology_build.py

        runtime_interaction_mapper.py
        signal_slot_reconstructor.py
        ui_action_registry_mapper.py
        dispatch_chain_mapper.py

        runtime_topology_indexer.py
        runtime_trace_registry.py
        runtime_compact_exporter.py

    exports/
        pecs_runtime_topology.json

archive/
    pecs_lite_v1/
        pecs_lite_runtime_core.py
        pecs_lite_runtime_cache.py

---

# PECS-LITE v2 PURPOSE

PECS-LITE v2 now performs compressed extraction of:
- QAction ownership
- signal-slot locality
- dispatch topology
- dialog ownership
- subprocess launch paths
- runtime continuity topology

WITHOUT heavy semantic reasoning.

---

# PECS-LITE v2 EXECUTION

Correct execution:

python -m pecs_lite.runtime.run_lite

NOT:

python runtime/run_lite.py

because PECS-LITE v2 is now:

package-structured architecture

and requires:
- __init__.py
- relative imports
- package execution

---

# IMPORTANT PYTHON PACKAGE FIXES

Generated v2 imports originally used flat imports like:

from runtime_interaction_mapper import RuntimeInteractionMapper

These must become package-relative imports:

from .runtime_interaction_mapper import RuntimeInteractionMapper

This applies across:
- runtime modules
- launcher modules
- topology modules

---

# EXPORT PRINCIPLE

PECS separates:
- source continuity
- generated continuity

Thus:

exports/

stores generated runtime continuity artifacts like:

pecs_runtime_topology.json

which is generated automatically after runtime execution.

---

# PECS-PRO v2 DIRECTION

PECS-PRO v2 must become:

topology-first continuity infrastructure

Required capabilities:
- runtime topology reconstruction
- execution graph indexing
- QAction ownership reconstruction
- signal-slot continuity
- dispatch-chain indexing
- subprocess topology indexing
- overlay propagation continuity
- viewer ownership continuity
- runtime confidence scoring
- topology-aware retrieval
- topology-aware incremental updates
- topology-aware continuity exports

---

# IMPORTANT PECS-PRO v2 CONSTRAINT

Do NOT:
- flatten architecture
- randomly replace files
- introduce autonomous AI orchestration
- create semantic AGI layers

Instead maintain:

strict continuity ownership discipline

---

# FINAL PECS v2 PRINCIPLE

The key discovery from the entire PECS evolution was:

continuity in large GUI systems is execution-topological

That is:

the actual PECS v2 breakthrough